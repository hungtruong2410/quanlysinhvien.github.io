﻿using System;
using System.Collections.Generic;

namespace QuanLyDiemDanhVaBaiTap.Models.DataLayer;

public partial class BaiTap
{
    public string? MaSinhVien { get; set; }

    public string? TenBaiTap { get; set; }

    public DateOnly? NgayNop { get; set; }

    public decimal? Diem { get; set; }

    public virtual SinhVien? MaSinhVienNavigation { get; set; }
}
