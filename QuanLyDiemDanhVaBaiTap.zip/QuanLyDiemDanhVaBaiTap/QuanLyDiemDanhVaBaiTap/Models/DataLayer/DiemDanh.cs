﻿using System;
using System.Collections.Generic;

namespace QuanLyDiemDanhVaBaiTap.Models.DataLayer;

public partial class DiemDanh
{
    public string? MaSinhVien { get; set; }

    public DateOnly? NgayDiemDanh { get; set; }

    public string? TinhTrang { get; set; }

    public virtual SinhVien? MaSinhVienNavigation { get; set; }
}
