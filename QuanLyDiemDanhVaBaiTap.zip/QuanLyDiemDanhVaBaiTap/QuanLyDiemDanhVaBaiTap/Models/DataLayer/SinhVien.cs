﻿using System;
using System.Collections.Generic;

namespace QuanLyDiemDanhVaBaiTap.Models.DataLayer;

public partial class SinhVien
{
    public string? MaSinhVien { get; set; }  // Sử dụng null-forgiving operator

	public string? HoTen { get; set; }

    public string? Lop { get; set; }
}
