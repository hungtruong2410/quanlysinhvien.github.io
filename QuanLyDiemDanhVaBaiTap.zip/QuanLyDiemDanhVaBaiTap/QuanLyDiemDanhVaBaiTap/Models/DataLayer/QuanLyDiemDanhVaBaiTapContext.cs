﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace QuanLyDiemDanhVaBaiTap.Models.DataLayer;

public partial class QuanLyDiemDanhVaBaiTapContext : DbContext
{
    public QuanLyDiemDanhVaBaiTapContext()
    {
    }

    public QuanLyDiemDanhVaBaiTapContext(DbContextOptions<QuanLyDiemDanhVaBaiTapContext> options)
        : base(options)
    {
    }

    public virtual DbSet<BaiTap> BaiTaps { get; set; }

    public virtual DbSet<DiemDanh> DiemDanhs { get; set; }

    public virtual DbSet<SinhVien> SinhViens { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
            optionsBuilder.UseSqlServer("name=MyConnection");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<BaiTap>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("BaiTap");

            entity.Property(e => e.Diem).HasColumnType("decimal(5, 2)");
            entity.Property(e => e.MaSinhVien)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.TenBaiTap).HasMaxLength(50);

            entity.HasOne(d => d.MaSinhVienNavigation).WithMany()
                .HasForeignKey(d => d.MaSinhVien)
                .HasConstraintName("FK__BaiTap__MaSinhVi__3A81B327");
        });

        modelBuilder.Entity<DiemDanh>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("DiemDanh");

            entity.Property(e => e.MaSinhVien)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.TinhTrang).HasMaxLength(20);

            entity.HasOne(d => d.MaSinhVienNavigation).WithMany()
                .HasForeignKey(d => d.MaSinhVien)
                .HasConstraintName("FK__DiemDanh__MaSinh__38996AB5");
        });

        modelBuilder.Entity<SinhVien>(entity =>
        {
            entity.HasKey(e => e.MaSinhVien).HasName("PK__SinhVien__939AE7751D864EE4");

            entity.ToTable("SinhVien");

            entity.Property(e => e.MaSinhVien)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.HoTen).HasMaxLength(50);
            entity.Property(e => e.Lop).HasMaxLength(20);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
