﻿using Microsoft.AspNetCore.Mvc;

namespace QuanLyDiemDanhVaBaiTap.Controllers
{
    public class BaiTapController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
