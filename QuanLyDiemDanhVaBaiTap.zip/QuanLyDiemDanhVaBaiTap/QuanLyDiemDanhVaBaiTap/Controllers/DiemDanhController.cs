﻿using Microsoft.AspNetCore.Mvc;

namespace QuanLyDiemDanhVaBaiTap.Controllers
{
    public class DiemDanhController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
