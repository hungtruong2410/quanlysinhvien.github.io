﻿using Microsoft.AspNetCore.Mvc;
using QuanLyDiemDanhVaBaiTap.Models;
using QuanLyDiemDanhVaBaiTap.Models.DataLayer;
using System.Diagnostics;

namespace QuanLyDiemDanhVaBaiTap.Controllers
{
    public class SinhVienController : Controller
    {
        private readonly ILogger<SinhVienController> _logger;
        private QuanLyDiemDanhVaBaiTapContext _context { get; set; }

        public SinhVienController(ILogger<SinhVienController> logger, QuanLyDiemDanhVaBaiTapContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult DanhSachSinhVien()
        {
            if (_context == null)
            {
                throw new InvalidOperationException("DbContext không được khởi tạo");
            }

            if (_context.SinhViens == null)
            {
                throw new InvalidOperationException("SinhViens không được khởi tạo");
            }

            IQueryable<SinhVien> query = _context.SinhViens;
            IEnumerable<SinhVien> sinhViens = query.ToList();
            return View(sinhViens);
        }

        public IActionResult Them()
        {
            return View();
        }

		public IActionResult Sua(string masv = "")
		{
			IQueryable<SinhVien> query = _context.SinhViens;
            var sinhVien = query.Where(sv => sv.MaSinhVien == masv).FirstOrDefault();
			return View(sinhVien);
			
		}
        [HttpPost]
        
        public IActionResult Sua(string masv, string hoTen, string lop)
		{
            var sinhVien = _context.SinhViens.Find(masv);
            sinhVien.HoTen = hoTen;
            sinhVien.Lop = lop;
            _context.SaveChanges();
            return RedirectToAction("DanhSachSinhVien", "SinhVien", new { sinhvien = sinhVien });
           
        }
        

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        
    }
}
